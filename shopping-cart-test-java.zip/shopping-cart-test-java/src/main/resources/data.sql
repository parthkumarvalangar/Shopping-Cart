-- Insert products

INSERT INTO PRODUCT (PRODUCT_ID, CATEGORY, DESCRIPTION, NAME, PRICE, QUANTITY) VALUES
(1, 'Radio', 'Portable satellite radio with vehicle kit', 'Onyx EZR Vehicle Kit', 79.99, 10),
(2, 'Radio', 'Satellite radio with home kit', 'Onyx EZR Home Kit', 89.99, 10),
(3, 'Radio', 'Speaker dock for Onyx EZR', 'Onyx EZR Speaker Dock', 119.99, 10),
(4, 'Radio', 'Advanced satellite radio with 360L', 'SiriusXM Tour', 149.99, 8),
(5, 'Radio', 'Bluetooth-enabled satellite radio', 'Roady BT', 99.99, 12),
(6, 'Radio', 'Bluetooth home kit for Lynx LH1', 'Lynx LH1 Bluetooth Home Kit', 19.99, 0),

(7, 'Home', 'Complete home kit for satellite radio', 'SXDH4 Home Kit', 49.99, 15),
(8, 'Home', 'Boombox speaker dock for SiriusXM Radio', 'SXSD2 Boombox', 119.99, 7),
(9, 'Home', 'Indoor/outdoor antenna for better signal', 'Indoor/Outdoor Antenna', 39.99, 20),
(10, 'Home', 'Extension cable for antenna', '50ft Antenna Extension Kit', 59.99, 0),

(11, 'Vehicle', 'Magnetic mount antenna for vehicles', 'Vehicle Antenna', 15.99, 25),
(12, 'Vehicle', 'FM direct adapter for car Radio', 'FM Direct Adapter', 15.99, 30),
(13, 'Vehicle', 'Mounting kit for dashboard and vents', 'Dash & Vent Mount', 19.99, 18),
(14, 'Vehicle', 'Power adapter for vehicle use', 'Vehicle Power Adapter', 14.99, 20),
(15, 'Vehicle', 'Docking station for vehicle Radio', 'Vehicle Dock', 24.99, 15),

(16, 'Signal', 'Kit for distributing satellite and cable signals', 'Signal Distribution Kit', 119.99, 5),
(17, 'Signal', 'Home signal distribution for SiriusXM and TV', 'Home Signal Distribution Kit', 89.99, 6),
(18, 'Signal', 'Adapter for cable routing', 'Cable Routing Adapter', 9.99, 10),
(19, 'Signal', 'Mounting prep pads for installation', 'Mounting Prep Pads', 4.99, 50),

(20, 'Audio', 'Headphones with built-in antenna', 'Antenna Headphones', 39.99, 10),
(21, 'Audio', 'Charger for SiriusXM devices', 'Device Charger', 19.99, 15),
(22, 'Audio', 'Audio cable for SiriusXM Radio', 'Audio Cable', 9.99, 20);

-- Insert sample users
INSERT INTO USERS (user_id, name, email) 
VALUES 
    (1, 'John Doe', 'john@example.com'),
    (2, 'Jane Smith', 'jane@example.com');