package com.shoppingCart.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "tax.rates")
@Data
public class TaxConfiguration {
    private double defaultTax;
    private Map<String, Double> category = new HashMap<>();
}