package com.shoppingCart.entity;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Data
@Getter
@Setter
public class Cart {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cartId;
    @OneToOne
    @JoinColumn(name = "users_user_id", referencedColumnName = "userId")
    private Users users;
    @OneToMany(cascade = CascadeType.ALL)
    private List<CartItem> items;
}