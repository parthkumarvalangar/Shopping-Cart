package com.shoppingCart.entity;

import com.shoppingCart.dto.ProductCategory;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Data
@Getter
@Setter
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long productId;
    private String name;
    private double price;
    private int quantity;
    private String description;
    @Enumerated(EnumType.STRING)
    private ProductCategory category = ProductCategory.DEFAULTTAX;  // Default category if none specified

}