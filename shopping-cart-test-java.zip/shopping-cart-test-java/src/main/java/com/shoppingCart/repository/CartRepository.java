package com.shoppingCart.repository;

import com.shoppingCart.entity.Cart;
import com.shoppingCart.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CartRepository extends JpaRepository<Cart, Long> {
    Cart findByUsers(Users user);

    Optional<Cart> findByUsers_UserId(Long userId);
}