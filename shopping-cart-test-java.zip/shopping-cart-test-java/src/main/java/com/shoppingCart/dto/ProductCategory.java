package com.shoppingCart.dto;

public enum ProductCategory {
    Radio,    // 5% tax
    Home,    // 8% tax
    Vehicle,    // 12% tax
    Signal,
    Audio,// 15% tax
    DEFAULTTAX  // 10% tax (default)
}