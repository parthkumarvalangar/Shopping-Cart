package com.shoppingCart.dto;

import lombok.Builder;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
@Builder
public class CartResponse {
    private Long cartId;
    private Long userId;
    private List<CartItemDTO> items;
    private double subtotal;
    private double totalTax;
    private double totalPrice;
    private Map<ProductCategory, Double> taxBreakdown; // Added tax breakdown by category
}