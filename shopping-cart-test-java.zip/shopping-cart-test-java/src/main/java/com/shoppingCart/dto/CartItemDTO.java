package com.shoppingCart.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CartItemDTO {
    private Long productId;
    private String productName;
    private ProductCategory category;
    private int quantity;
    private double price;
    private double subtotal;
    private double tax;
    private double total;
    private double appliedTaxRate; // Added to show which tax rate was applied
}