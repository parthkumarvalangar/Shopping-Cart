package com.shoppingCart.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@AllArgsConstructor
public class CheckoutResponse {
    private Long cartId;
    private double total;
    private double subtotal;
    private double taxAmount;
}