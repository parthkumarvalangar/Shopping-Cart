package com.shoppingCart.service;

import com.shoppingCart.entity.Users;
import com.shoppingCart.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository repo;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    public Users save(Users users) {
        return repo.save(users);
    }
}