package com.shoppingCart.service;

import com.shoppingCart.config.TaxConfiguration;
import com.shoppingCart.entity.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class TaxService {
    private final TaxConfiguration taxConfig;

    public double calculateTax(Product product, double amount) {
        String category = product.getCategory().name();
        double taxRate = taxConfig.getCategory()
                .getOrDefault(category, taxConfig.getDefaultTax());
        return roundTax(amount * taxRate);
    }

    private double roundTax(double amount) {
        return Math.round(amount * 100.0) / 100.0;
    }
}