package com.shoppingCart.service;

import com.shoppingCart.config.TaxConfiguration;
import com.shoppingCart.dto.CartItemDTO;
import com.shoppingCart.dto.CartResponse;
import com.shoppingCart.dto.CheckoutResponse;
import com.shoppingCart.dto.ProductCategory;
import com.shoppingCart.entity.Cart;
import com.shoppingCart.entity.CartItem;
import com.shoppingCart.entity.Product;
import com.shoppingCart.entity.Users;
import com.shoppingCart.exception.InsufficientInventoryException;
import com.shoppingCart.exception.UserNotFoundException;
import com.shoppingCart.repository.CartRepository;
import com.shoppingCart.repository.ProductRepository;
import com.shoppingCart.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityNotFoundException;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
public class CartService {

    private static final Logger logger = LoggerFactory.getLogger(CartService.class);

    private final CartRepository cartRepo;
    private final ProductRepository productRepo;
    private final UserRepository userRepository;
    private final TaxService taxService;
    private final TaxConfiguration taxConfig;

    public CartService(CartRepository cartRepo, ProductRepository productRepo, UserRepository userRepository, TaxService taxService, TaxConfiguration taxConfig) {
        this.cartRepo = cartRepo;
        this.productRepo = productRepo;
        this.userRepository = userRepository;

        this.taxService = taxService;
        this.taxConfig = taxConfig;
    }

        public Cart getCartForUser(Long userId) {
            if (userId == null) {
                throw new IllegalArgumentException("User ID cannot be null");
            }

            return cartRepo.findByUsers_UserId(userId)
                    .orElseGet(() -> {
                        Cart newCart = new Cart();
                        Users user = userRepository.findById(userId)
                                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));
                        newCart.setUsers(user);
                        newCart.setItems(new ArrayList<>());
                        return cartRepo.save(newCart);
                    });
        }

    private void validateInventoryAvailability(Product product, int requestedQty) {
        if (product.getQuantity() < requestedQty) {
            throw new InsufficientInventoryException(
                    String.format("Required quantity %d not available. Available: %d",
                            requestedQty, product.getQuantity())
            );
        }
    }

    public CheckoutResponse checkout(Long userId) {
        Cart cart = cartRepo.findByUsers(userRepository.findById(userId).orElseThrow());

        // Calculate subtotal using BigDecimal
        BigDecimal subtotal = cart.getItems().stream()
                .map(item -> {
                            BigDecimal baseAmount = BigDecimal.valueOf(item.getProduct().getPrice())
                                    .multiply(BigDecimal.valueOf(item.getQuantity()));

                            BigDecimal taxAmount = BigDecimal.valueOf(taxService.calculateTax(item.getProduct(), Double.valueOf(String.valueOf(baseAmount))));
                            return baseAmount.add(taxAmount);
                        }

                )
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        // Calculate tax (assuming 3% tax rate)
        BigDecimal taxRate = new BigDecimal("0.03"); // 3% tax
        BigDecimal taxAmount = subtotal.multiply(taxRate);

        // Calculate total with tax
        BigDecimal totalWithTax = subtotal.add(taxAmount);

        // In a production system, consider updating CheckoutResponse to use BigDecimal
        return new CheckoutResponse(
                cart.getCartId(),
                totalWithTax.doubleValue(),
                subtotal.doubleValue(),
                taxAmount.doubleValue()
        );
    }


    @Transactional(isolation = Isolation.SERIALIZABLE)
    public Cart addToCart(Long usersId, Long productId, int qty) {
        logger.info("Adding {} items of product {} to cart for user {}", qty, productId, usersId);


        // Validate input parameters
        validateInputParameters(usersId, productId, qty);

        // Get product and user with a single database call
        Product product = productRepo.findById(productId)
                .orElseThrow(() -> new EntityNotFoundException("Product with ID " + productId + " not found"));
        Users user = userRepository.findById(usersId)
                .orElseThrow(() -> new EntityNotFoundException("User with ID " + usersId + " not found"));

        // Get or create cart
        Cart cart = getOrCreateCart(user);

        // Update cart items and get quantity difference
        int quantityToDeduct = updateCartItems(cart, product, qty);

        // Update product inventory
        updateProductInventory(product, quantityToDeduct);

        // Save all changes and refresh cart
        return cartRepo.saveAndFlush(cart);
    }

    private void validateInputParameters(Long usersId, Long productId, int qty) {
        if (usersId == null || productId == null) {
            throw new IllegalArgumentException("User ID and Product ID cannot be null");
        }
        if (qty <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero");
        }
    }

    private Cart getOrCreateCart(Users user) {
        return Optional.ofNullable(cartRepo.findByUsers(user))
                .orElseGet(() -> {
                    Cart newCart = new Cart();
                    newCart.setUsers(user);
                    newCart.setItems(new ArrayList<>());
                    return newCart;
                });
    }

    private int updateCartItems(Cart cart, Product product, int qty) {
        AtomicInteger quantityToDeduct = new AtomicInteger(qty);

        cart.getItems().stream()
                .filter(item -> item.getProduct().getProductId().equals(product.getProductId()))
                .findFirst()
                .ifPresentOrElse(
                        // Update existing item
                        existingItem -> {
                            int newQty = existingItem.getQuantity() + qty;
                            // Validate if additional quantity is available
                            if (product.getQuantity() < qty) {
                                throw new InsufficientInventoryException(
                                        String.format("Cannot add %d more units. Available: %d",
                                                qty, product.getQuantity())
                                );
                            }
                            existingItem.setQuantity(newQty);
                        },
                        // Add new item
                        () -> {
                            // Validate if requested quantity is available
                            if (product.getQuantity() < qty) {
                                throw new InsufficientInventoryException(
                                        String.format("Required quantity %d not available. Available: %d",
                                                qty, product.getQuantity())
                                );
                            }
                            CartItem newItem = new CartItem();
                            newItem.setProduct(product);
                            newItem.setQuantity(qty);
                            cart.getItems().add(newItem);
                        }
                );

        return quantityToDeduct.get();
    }

    private void updateProductInventory(Product product, int quantityToDeduct) {
        if (product.getQuantity() < quantityToDeduct) {
            throw new InsufficientInventoryException(
                    String.format("Insufficient inventory. Required: %d, Available: %d",
                            quantityToDeduct, product.getQuantity())
            );
        }
        product.setQuantity(product.getQuantity() - quantityToDeduct);
        productRepo.save(product);
    }

    public Cart getCartDetails(Long userId) {
        Users user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        Cart cart = cartRepo.findByUsers(user);
        if (cart == null) {
            throw new EntityNotFoundException("Cart not found for user");
        }
        return cart;
    }


    @Transactional(isolation = Isolation.SERIALIZABLE)
    public Cart removeFromCart(Long usersId, Long productId, int qtyToRemove) {
        logger.info("Removing {} items of product {} from cart for user {}", qtyToRemove, productId, usersId);

        // Validate input parameters
        validateInputParameters(usersId, productId, qtyToRemove);

        // Get product and user with a single database call
        Product product = productRepo.findById(productId)
                .orElseThrow(() -> new EntityNotFoundException("Product with ID " + productId + " not found"));
        Users user = userRepository.findById(usersId)
                .orElseThrow(() -> new EntityNotFoundException("User with ID " + usersId + " not found"));

        // Get existing cart
        Cart cart = getOrCreateCart(user);


        // Remove items from cart and get quantity to return to inventory
        int quantityToReturnToStock = removeCartItems(cart, product, qtyToRemove);

        // Update product inventory by adding back the removed quantity
        updateProductInventoryForRemoval(product, quantityToReturnToStock);

        // If cart is empty after removal, you might want to delete it
        if (cart.getItems().isEmpty()) {
            cartRepo.delete(cart);
            return null;
        }

        // Save all changes and refresh cart
        return cartRepo.saveAndFlush(cart);
    }

    private int removeCartItems(Cart cart, Product product, int qtyToRemove) {
        CartItem existingItem = cart.getItems().stream()
                .filter(item -> item.getProduct().getProductId().equals(product.getProductId()))
                .findFirst()
                .orElseThrow(() -> new EntityNotFoundException("Product not found in cart"));

        int currentQty = existingItem.getQuantity();
        if (qtyToRemove >= currentQty) {
            // Remove the entire item if quantity to remove is greater than or equal to current quantity
            cart.getItems().remove(existingItem);
            return currentQty;
        } else {
            // Reduce the quantity
            existingItem.setQuantity(currentQty - qtyToRemove);
            return qtyToRemove;
        }
    }

    private void updateProductInventoryForRemoval(Product product, int quantityToReturn) {
        int updatedStock = product.getQuantity() + quantityToReturn;
        product.setQuantity(updatedStock);
        productRepo.save(product);
    }

    public CartResponse buildCartResponse(Cart cart) {
        // Handle null cart case
        if (cart == null) {
            return CartResponse.builder()
                    .cartId(null)
                    .userId(null)
                    .items(new ArrayList<>())
                    .subtotal(0.0)
                    .totalTax(0.0)
                    .totalPrice(0.0)
                    .taxBreakdown(new HashMap<>())
                    .build();
        }

        // Handle cart with null items
        if (cart.getItems() == null) {
            return CartResponse.builder()
                    .cartId(cart.getCartId())
                    .userId(cart.getUsers() != null ? cart.getUsers().getUserId() : null)
                    .items(new ArrayList<>())
                    .subtotal(0.0)
                    .totalTax(0.0)
                    .totalPrice(0.0)
                    .taxBreakdown(new HashMap<>())
                    .build();
        }

        // Process normal cart with items
        List<CartItemDTO> items = cart.getItems().stream()
                .map(this::buildCartItemDTO)
                .collect(Collectors.toList());

        double subtotal = items.isEmpty() ? 0.0 : items.stream()
                .mapToDouble(CartItemDTO::getSubtotal)
                .sum();

        double totalTax = items.isEmpty() ? 0.0 : items.stream()
                .mapToDouble(CartItemDTO::getTax)
                .sum();

        // Calculate tax breakdown by category only if there are items
        Map<ProductCategory, Double> taxBreakdown = items.isEmpty()
                ? new HashMap<>()
                : items.stream()
                .collect(Collectors.groupingBy(
                        CartItemDTO::getCategory,
                        Collectors.summingDouble(CartItemDTO::getTax)
                ));

        return CartResponse.builder()
                .cartId(cart.getCartId())
                .userId(cart.getUsers() != null ? cart.getUsers().getUserId() : null)
                .items(items)
                .subtotal(subtotal)
                .totalTax(totalTax)
                .totalPrice(subtotal + totalTax)
                .taxBreakdown(taxBreakdown)
                .build();
    }

    private CartItemDTO buildCartItemDTO(CartItem item) {
        Product product = item.getProduct();
        double subtotal = item.getQuantity() * product.getPrice();
        double tax = taxService.calculateTax(product, subtotal);
        double taxRate = taxConfig.getCategory()
                .getOrDefault(product.getCategory().name(), taxConfig.getDefaultTax());

        return CartItemDTO.builder()
                .productId(product.getProductId())
                .productName(product.getName())
                .category(product.getCategory())
                .quantity(item.getQuantity())
                .price(product.getPrice())
                .subtotal(subtotal)
                .tax(tax)
                .total(subtotal + tax)
                .appliedTaxRate(taxRate)
                .build();
    }
}