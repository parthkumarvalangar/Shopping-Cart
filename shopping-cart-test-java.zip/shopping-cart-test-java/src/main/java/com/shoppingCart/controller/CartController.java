package com.shoppingCart.controller;

import com.shoppingCart.config.TaxConfiguration;
import com.shoppingCart.dto.CartItemDTO;
import com.shoppingCart.dto.CartResponse;
import com.shoppingCart.dto.CheckoutResponse;
import com.shoppingCart.dto.ProductCategory;
import com.shoppingCart.entity.Cart;
import com.shoppingCart.entity.CartItem;
import com.shoppingCart.entity.Product;
import com.shoppingCart.service.CartService;
import com.shoppingCart.service.TaxService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/cart")
public class CartController {
    private final CartService service;
    private final TaxService taxService;
    private final TaxConfiguration taxConfig;

    public CartController(CartService service, TaxService taxService, TaxConfiguration taxConfig) {
        this.service = service;
        this.taxService = taxService;
        this.taxConfig = taxConfig;
    }




    @PostMapping("/remove")
    public ResponseEntity<CartResponse> removeFromCart(@RequestParam Long userId,
                                                  @RequestParam Long productId,
                                                  @RequestParam int qty) {
        Cart updatedCart = service.removeFromCart(userId, productId, qty);
        CartResponse response = service.buildCartResponse(updatedCart);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/add")
    public ResponseEntity<CartResponse> addToCart(@RequestParam Long userId,
                                                  @RequestParam Long productId,
                                                  @RequestParam int qty) {
        Cart updatedCart = service.addToCart(userId, productId, qty);
        CartResponse response = service.buildCartResponse(updatedCart);
        return ResponseEntity.ok(response);
    }




    @PostMapping("/user/{userId}")
    public Cart getCartForUser(@PathVariable Long userId) {
        return service.getCartForUser(userId);
    }

    @GetMapping("/checkout/{userId}")
    public CheckoutResponse checkout(@PathVariable Long userId) {
        return service.checkout(userId);
    }
}