package com.shoppingCart.controller;

import com.shoppingCart.dto.CheckoutResponse;
import com.shoppingCart.entity.Product;
import com.shoppingCart.service.CartService;
import com.shoppingCart.service.ProductService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {
    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }


    @PostMapping
    public Product addProduct(@RequestBody Product product) {
        return service.save(product);
    }

    @GetMapping
    public List<Product> getAll() {
        return service.findAll();
    }

   /* @DeleteMapping("/delete/{productId}")
    public String checkout(@PathVariable Long productId) {
        // First delete related cart items --> PENDING
      //  service.deleteProductById(productId);
         return "Successfully deleted product with ID ::"+productId;
    }*/
}